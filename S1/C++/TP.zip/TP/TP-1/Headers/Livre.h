/*
 * Livre.h
 *
 *  Created on: 25 sept. 2019
 *      Author: 3670958
 */

#ifndef HEADERS_LIVRE_H_
#define HEADERS_LIVRE_H_

#include "Papier.h"
class Livre : public Papier{
public:
	Livre();
};



#endif /* HEADERS_LIVRE_H_ */
