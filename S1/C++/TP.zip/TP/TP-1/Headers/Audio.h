/*
 * Audio.h
 *
 *  Created on: 25 sept. 2019
 *      Author: 3670958
 */

#ifndef HEADERS_AUDIO_H_
#define HEADERS_AUDIO_H_
#include "Numeric.h"
class Audio: public Numeric{
public:
	Audio();
	void Afficher();
};




#endif /* HEADERS_AUDIO_H_ */
