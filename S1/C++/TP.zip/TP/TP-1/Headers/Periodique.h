/*
 * Periodique.h
 *
 *  Created on: 25 sept. 2019
 *      Author: 3670958
 */

#ifndef HEADERS_PERIODIQUE_H_
#define HEADERS_PERIODIQUE_H_
#include "Papier.h"
class Periodique : public Papier{
public:
	Periodique();
};




#endif /* HEADERS_PERIODIQUE_H_ */
