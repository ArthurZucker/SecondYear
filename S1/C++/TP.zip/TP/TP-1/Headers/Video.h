/*
 * Video.h
 *
 *  Created on: 25 sept. 2019
 *      Author: 3670958
 */

#ifndef HEADERS_VIDEO_H_
#define HEADERS_VIDEO_H_
#include "Numeric.h"
class Video: public Numeric{
public:
	Video();
	void Afficher();
};




#endif /* HEADERS_VIDEO_H_ */
