#ifndef BIBLI_h
#define BIBLI_h
#include <iostream>
#include <string>
#include <vector>
#include "adherent.h"
#include "document.h"
using namespace std;
class bibli {
private:
	vector<Adherent*> list_adherents;
	vector<Document*> list_documents;
	string nom;
public:
	bibli(string);
	string get_nom();
	Document get_document_list();
	Adherent get_adherent_list();
	int set_nom(string);
	int add_doc(Document*);
	int add_adhe(Adherent*);
	void afficher();
	void afficher_adhe();
	void afficher_doc();
	void remove_doc(string);
	void remove_adhe(string);
	void remove_doc(Document);
	void remove_adhe(Adherent);
	~bibli();
	const vector<Adherent*>& getListAdherents() const;
	const vector<Document*>& getListDocuments() const;
	const string& getNom() const;
	void setNom(const string& nom);
};
#endif
