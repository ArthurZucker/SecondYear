
/*
 * Audio.cpp
 *
 *  Created on: 25 sept. 2019
 *      Author: 3670958
 */
#include "../Headers/Audio.h"
#include <iostream>
 Audio::Audio():Numeric(true,23) {
}

void Audio::Afficher() {
	cout << "HAHAHAH pire programe";
}

