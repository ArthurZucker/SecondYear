#include "../Headers/Livre.h"
Livre::Livre() : Papier(1,36){
}
/*
 * Livre.cpp
 *
 *  Created on: 25 sept. 2019
 *      Author: 3670958
 */




