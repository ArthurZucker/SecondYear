
/*
 * Periodique.cpp
 *
 *  Created on: 25 sept. 2019
 *      Author: 3670958
 */
#include "../Headers/Periodique.h"
Periodique::Periodique() : Papier(true,15){

}


