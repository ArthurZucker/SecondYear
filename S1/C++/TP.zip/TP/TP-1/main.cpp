#include "./Headers/document.h"
int Document::cpt = 0;
int main(){
	return 1;
}
