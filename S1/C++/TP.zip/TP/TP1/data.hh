#ifndef _DATA_HH_
#define _DATA_HH_
#include <random>
const short print_width(3);
const short MAX_ASKI{61};
const short MIN_ASKI{34};
namespace alea{
	unsigned int dice();
}
#endif
