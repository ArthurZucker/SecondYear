#ifndef __MATRIX_H__
#define __MATRIX_H__
#include "tableau2D.hh"
#include <iostream>
#include <type_traits>
#include <memory>
template <typename T>
using EnableIfPolicy = typename std::enable_if<std::is_arithmetic<T>::value>::type;
template <typename U>
using EnableIfPolicy2 = typename std::enable_if<std::is_floating_point<U>::value>::type;

template <typename T>
class Matrix : public Tableau2D<T>
{
public:
	static bool identity;

public:
	Matrix(std::size_t nbC, std::size_t nbL, T value);
	Matrix(std::size_t nbC, std::size_t nbL, bool &ma);
	Matrix<T> &operator+(const Matrix<T> &right);
	template <typename U, typename std::enable_if<std::is_arithmetic<U>::value>::type * = nullptr>
	friend Matrix<T> &operator*(const U &left, Matrix<T> &right)
	{
		for (size_t i = 0; i < right.nbLine; i++)
		{
			for (size_t ii = 0; ii < right.nbColumn; ii++)
			{
				right.table[i][ii] *= left;
			}
		}
		return right;
	}
	template <typename U>
	Matrix<T> &operator+(const U &right);
	template <typename U>
	Matrix<T> &operator/(const U &right);
	template <typename U, EnableIfPolicy2<U>>
	Matrix<U> &operator/(const U &right);
	template <typename U, typename std::enable_if<std::is_floating_point<U>::value>::type * = nullptr>
	friend Matrix<U> &operator*(const U &left, Matrix<T> &right)
	{
		for (size_t i = 0; i < right.nbLine; i++)
		{
			for (size_t ii = 0; ii < right.nbColumn; ii++)
			{
				right.table[i][ii] *= left;
			}
		}
		return right;
	}
	Matrix<T> &operator*(Matrix<T> const &right);
	Matrix<T> &transpose();
	~Matrix();
};


template <typename T>
Matrix<T> &Matrix<T>::operator*(Matrix<T> const &right)
{
	if (this->nbColumn == right.nbLine)
	{
		Matrix<T> res = Matrix(this->nbLine, this->nbColumn,0);
		for (size_t i = 0; i < this->nbLine; i++)
		{
			for (size_t ii = 0; ii < this->nbColumn; ii++)
			{

				for (size_t j = 0; j < this->nbColumn; j++)
				{
					res.table[i][ii] += (this->table[i][j]*right(j, ii));
				}
			}
		}
		*this = res;
		return *this;
	}
	else
	{
		std::cerr << "Error matrix dimension don't agree";
	}
}

template <typename T>
Matrix<T>::Matrix(std::size_t nbC, std::size_t nbL, T value) : Tableau2D<T>(nbC, nbL)
{
	for (size_t i = 0; i < nbL; i++)
	{
		for (size_t ii = 0; ii < nbC; ii++)
		{
			this->table[i][ii] = value;
		}
	}
}
template <typename T>
Matrix<T>::Matrix(std::size_t nbC, std::size_t nbL, bool &id) : Matrix(nbC, nbL, 0)
{
	if (id == true)
	{
		for (size_t ii = 0; ii < nbC; ii++)
		{
			this->table[ii][ii] = 1;
		}
	}
}

template <typename T>
template <typename U>
Matrix<T> &Matrix<T>::operator+(const U &right)
{
	for (size_t i = 0; i < this->nbLine; i++)
	{
		for (size_t ii = 0; ii < this->nbColumn; ii++)
		{
			this->table[i][ii] += right;
		}
	}
	return *this;
}

template <typename T>
template <typename U>
Matrix<T> &Matrix<T>::operator/(const U &right)
{
	for (size_t i = 0; i < this->nbLine; i++)
	{
		for (size_t ii = 0; ii < this->nbColumn; ii++)
		{
			this->table[i][ii] /= right;
		}
	}
	return *this;
}

template <typename T>
template <typename U, EnableIfPolicy2<U>>
Matrix<U> &Matrix<T>::operator/(const U &right)
{
	for (size_t i = 0; i < this->nbLine; i++)
	{
		for (size_t ii = 0; ii < this->nbColumn; ii++)
		{
			this->table[i][ii] /= right;
		}
	}
	return *this;
}

template <typename T>
Matrix<T> &Matrix<T>::operator+(const Matrix<T> &right)
{
	if (this->nbColumn != right.nbColumn || this->nbLine != right.nbLine)
	{
		return *this;
	}
	else
	{
		for (size_t i = 0; i < this->nbLine; i++)
		{
			for (size_t ii = 0; ii < this->nbColumn; ii++)
			{
				this->table[i][ii] += right(i, ii);
			}
		}
		return *this;
	}
}

template <typename T>
bool Matrix<T>::identity = true;

template <typename T>
Matrix<T>::~Matrix()
{
}




template <typename T>
Matrix<T> &Matrix<T>::transpose()
{
	Matrix<T> res =  Matrix(this->nbColumn, this->nbLine,0);
	for (size_t i = 0; i < this->nbLine; i++)
	{

		for (size_t j = 0; j <this->nbColumn ; j++)
		{
			res(i,j) = this->table[j][i];
		}
	}
	*this = res;
	return *this;
}


#endif