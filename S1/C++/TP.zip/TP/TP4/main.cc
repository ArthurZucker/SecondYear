#include "tableau2D.hh"
#include "Matrix.hh"
int main(void)
{

  Tableau2D<float> tab(10, 10);
  tab(2, 2) = 42.0;
  std::cout << tab(2, 2) << std::endl;

  Tableau2D<float> tab2 = tab;
  if (tab2 == tab)
    std::cout << "equal" << std::endl;
  tab2(1, 1) = 1.5;

  if (tab2 == tab)
    std::cout << "equal" << std::endl;
  std::cout << tab2 << std::endl;

  Matrix<float> a1(5, 5, 1);
  Matrix<float> a2(5, 5, 0);
  std::cout <<"a1"<< '\n'<< a1 << std::endl;
  std::cout <<"a2"<< '\n'<< a1 << std::endl;
  Matrix<float> a3 = a2;
  std::cout <<"a3"<< '\n'<< a1 << std::endl;
  Matrix<float> a4 = 2 * (a1 + a2 + a3);
  std::cout <<"a4"<< '\n'<< a1 << std::endl;
  a3 = a4 / 2.0;
  std::cout << "a3"<< '\n'<<a3 << std::endl;
  Matrix<float> a5(5, 5, Matrix<float>::identity);
  std::cout << a5 << std::endl;

  std::cout <<"a3*a5"<< '\n'<< a3*a5 << std::endl;
  std::cout <<"a3*a4"<< '\n'<< a3*a4 << std::endl;
  std::cout <<"a3.t()"<< '\n'<< a3.transpose() << std::endl;
  std::cout <<"(a3+a5).t()"<< '\n'<< (a3+a5).transpose() << std::endl;
  a5(2,3) = 9;
  a5(2,1) = 8;
  std::cout <<"a5"<< '\n'<< a5 << std::endl;
  std::cout <<"a5.t()"<< '\n'<<a5.transpose() << std::endl;
  
}
