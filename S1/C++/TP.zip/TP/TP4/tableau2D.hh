#pragma once
#include <iostream>
#include <iomanip>
template <typename T>
class Tableau2D
{
protected:
  T **table;
  std::size_t nbLine;
  std::size_t nbColumn;

public:
  Tableau2D(std::size_t nbC, std::size_t nbL);
  Tableau2D(const Tableau2D &);
  T operator()(std::size_t C, std::size_t L) const;
  T &operator()(std::size_t C, std::size_t L);
  template <typename U>
  friend std::ostream &operator<<(std::ostream &, const Tableau2D<U> &);
  bool operator==(const Tableau2D<T> &lhs) const;
  Tableau2D<T> &operator=(const Tableau2D<T> &m);
  virtual ~Tableau2D();
};
template <typename T>
Tableau2D<T>::Tableau2D(std::size_t nbC, std::size_t nbL) : nbLine(nbL), nbColumn(nbC)
{
  table = new T *[nbL];
  for (size_t i = 0; i < nbL; i++)
  {
    table[i] = new T[nbC];
  }
}
template <typename T>
Tableau2D<T>::Tableau2D(const Tableau2D<T> &t) : nbLine(t.nbLine), nbColumn(t.nbColumn)
{
  table = new T *[t.nbLine];
  for (size_t i = 0; i < t.nbLine; i++)
  {
    table[i] = new T[t.nbColumn];
    for (size_t ii = 0; ii < t.nbColumn; ii++)
    {
      table[i][ii] = t.table[i][ii];
    }
  }
}
template <typename T>
Tableau2D<T>::~Tableau2D()
{
  for (size_t i = 0; i < nbColumn; i++)
  {
    delete[] table[i];
  }
  delete[] table;
}

template <typename T>
std::ostream &operator<<(std::ostream &os, const Tableau2D<T> &t)
{
  for (size_t i = 0; i < t.nbLine; i++)
  {
    os << '|';
    for (size_t ii = 0; ii < t.nbColumn; ii++)
    {
      os << std::setw(4) << std::setfill(' ') << t.table[i][ii] << '|';
    }
    os << '\n';
  }
  return os;
}

template <typename T>
bool Tableau2D<T>::operator==(const Tableau2D<T> &rhs) const
{
  if (nbLine != rhs.nbLine || nbColumn != rhs.nbColumn)
  {
    return false;
  }
  else
  {
    for (size_t i = 0; i < nbLine; i++)
    {
      for (size_t ii = 0; ii < nbColumn; ii++)
      {
        if (table[i][ii] != rhs.table[i][ii])
        {
          return false;
        }
      }
    }
    return true;
  }
}
template <typename T>
Tableau2D<T> &Tableau2D<T>::operator=(const Tableau2D<T> &t)
{
  for (size_t i = 0; i < nbColumn; i++)
  {
    try
    {
      delete[] table[i];
    }
    catch (...)
    {
      std::cout<<"catched"<<std::endl;
    }
  }
  try
  {
     delete[] table;
  }
  catch (...)
  {
    std::cout<<"catched"<<std::endl;
   
  }
  // Try and catch to prevent cases when the object was not instanciated
  this->nbColumn = t.nbColumn;
  this->nbLine = t.nbLine;
  table = new T *[t.nbLine];
  for (size_t i = 0; i < t.nbLine; i++)
  {
    table[i] = new T[t.nbColumn];
    for (size_t ii = 0; ii < t.nbColumn; ii++)
    {
      table[i][ii] = t.table[i][ii];
    }
  }

  return *this;
}

template <typename T>
T Tableau2D<T>::operator()(std::size_t C, std::size_t L) const
{
  return table[C][L];
}
template <typename T>
T &Tableau2D<T>::operator()(std::size_t C, std::size_t L)
{
  return table[C][L];
}
