# TP sur les templates

* tp5.pdf : l'énoncé
* main.cc, tableau2D.hh : fichiers pour l'exercice 1
