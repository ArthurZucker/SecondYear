#include <iostream>

#include "screen.hh"
#include "ball.hh"
#include "cube.hh"
#include "simu.hh"
#include "randgen.hh"

int main(int argc, char **argv)
{
  std::cerr << "to quit, type C-c in the terminal" << std::endl;
  srand(time(0));
  Simu s(500, 500);
  s += new Cube(randgen::uniform(300) + 100, randgen::uniform(300) + 100,
                randgen::uniform(50) - 25, randgen::uniform(50) - 25,
                randgen::uniform(100), randgen::uniform(100));

  for (size_t i = 0; i < 3; ++i)
    s += new Ball(randgen::uniform(300) + 100, randgen::uniform(300) + 100,
                  randgen::uniform(50) - 25, randgen::uniform(50) - 25,
                  randgen::uniform(30));

  for (size_t i = 0; i < 15000; ++i)
    s.update();

  return 0;
}
