#include "ball.hh"
Ball::Ball(float x, float y, float vx, float vy, int radius) : x(x),y(y),vx(vx),vy(vy),ax(0),ay(9),radius(radius){

}

void Ball::update(Screen &S){

	if (this->is_collided_edges(S) == false ) {
		this->x += game::dt*this->vx;
	}
	else{
		this->vx *= -game::kx;
		this->vy *= game::ky;
	}
	if (this->is_collided_floor(S) == false) {
		this->y += game::dt*this->vy;
	}
	else{
		this->vx *= game::kx;
		this->vy *= -game::ky;
	}
	this->vy += game::dt*this->ay;
	this->vx += game::dt*this->ax;

}
void Ball::draw(Screen &S){
	S.disc(this->x,this->y,this->radius);
}
bool Ball::is_collided_floor(const Screen &S) const{
	 if((this->y + game::dt*this->vy + this->radius) < S.h()){
		 return false;
	 }
	return true;
}

bool Ball::is_collided_edges(const Screen &S) const{
	 if((this->x + game::dt*this->vx + this->radius) < S.w() && (this->x + game::dt*this->vx - this->radius) >0 ){
		 return false;
	 }
	return true;
}
