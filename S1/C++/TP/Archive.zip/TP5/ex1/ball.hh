#ifndef __BALL_HH
#define __BALL_HH
#include "screen.hh"
namespace game {
	const float dt = 0.01;
	const float kx = 0.95;
	const float ky = 0.85;
} /* game */
class Ball {
private:
	float x,y,vx,vy,ax,ay;
	int radius;
public:
	Ball (float, float, float, float, int);
	void update(Screen &);
	void draw(Screen &);
	bool is_collided_edges(const Screen &S) const;
	bool is_collided_floor(const Screen &S) const;
	virtual ~Ball (){};
};
#endif
