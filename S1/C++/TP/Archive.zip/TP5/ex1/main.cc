#include <iostream>

#include "screen.hh"
#include "ball.hh"

int main(int argc, char **argv)
{
  std::cerr << "to quit, type C-c in the terminal" << std::endl;
  srand(time(0));
  Screen screen(500, 500);
  Ball b1(100, 200, 10, 20, 22);
  Ball b2(150, 20, 10, -30, 12);

  while (1)
  {
    b1.update(screen);
    b2.update(screen);

    b1.draw(screen);
    b2.draw(screen);

    screen.flip();
  }
}

