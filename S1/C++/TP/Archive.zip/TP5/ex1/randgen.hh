#ifndef RANDOM_HPP_
#define RANDOM_HPP_

#include <cstdlib>
#include <cmath>
#include <cassert>

namespace randgen
{
   // NOT Thread-safe !
  template<typename T>
  inline T uniform(T max = 1.0)
  {
    assert(max > 0);
    T v;
    do
      v = T(((double)max * ::rand()) / (RAND_MAX + 1.0));
    while (v >= max);
    assert(v < max);
    return v;
  }

  template<typename T>
  inline T gaussian(T m = 0.0, T v = 1.0)
  {
    float facteur = sqrt(-2.0f * log(uniform<float>()));
    float trigo = 2.0f *M_PI *uniform<float>();
    return T(m + v * facteur * cos(trigo));
  }

}

#endif
