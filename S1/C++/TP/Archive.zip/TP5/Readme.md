# TP6: Balle rebondissante
* tp6.pdf : le sujet
* ex1 ex2 ex3 : répertoire contentant les fichiers utiles aux
  exercices
  * randgen.hh : pour générer des nombres aléatoires
  * screen.hh, screen.cc : pour utiliser la SDL
  * Makefile : avec les bonnes options de compilation pour la SDL
  
# le lien
