#include "cube.hh"
Cube::Cube (float x, float y, float vx, float vy, float w, float h) : Figure(x,y,vx,vy,0,9),w(w),h(h){

}

void Cube::update(Screen &S){

	if (this->is_collided_edges(S) == false ) {
		this->x += game::dt*this->vx;
	}
	else{
		this->vx *= -game::kx;
		this->vy *= game::ky;
	}
	if (this->is_collided_floor(S) == false) {
		this->y += game::dt*this->vy;
	}
	else{
		this->vx *= game::kx;
		this->vy *= -game::ky;
	}
	this->vy += game::dt*this->ay;
	this->vx += game::dt*this->ax;

}
void Cube::draw(Screen &S) const{
	S.rect(this->x,this->y,this->w,this->h);
}
//Not adapted to cube yet
bool Cube::is_collided_floor(const Screen &S) const{
	 if((this->y + game::dt*this->vy + (this->h)/2) < S.h()  ){
		 return false;
	 }
	return true;
}
//Not adapted to cube yet
bool Cube::is_collided_edges(const Screen &S) const{
	 if((this->x + game::dt*this->vx + (this->w)/2) < S.w() && ((this->x) + game::dt*this->vx - (this->w)/2) >0 )
	 {
		 return false;
	 }
	return true;
}
