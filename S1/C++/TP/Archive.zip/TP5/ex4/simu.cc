#include "simu.hh"
Simu::Simu (size_t x,size_t y):S(x,y){

}
Simu& Simu::operator +=(Figure *z){
	(this->objets).push_back(z);
	return *this;
}
void Simu::update(){
	for(Figure *&x :objets){
		x->update(S);
		x->draw(S);

	}
	S.flip();
}
Simu::~Simu(){

}
