#ifndef __SIMU_HH__
#define __SIMU_HH__
#include "figure.hh"
#include "screen.hh"
#include <list>
class Simu {
private:
	Screen S;
	std::list<Figure *> objets;

public:
	Simu (size_t,size_t);
	Simu& operator +=(Figure *);
	void update();
	virtual ~Simu ();
};

#endif
