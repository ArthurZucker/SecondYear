#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

#include "screen.hh"
#include "ball.hh"
#include "cube.hh"
#include "simu.hh"
#include "randgen.hh"
#include "utility.hh"

int main(int argc, char **argv)
{
  std::cerr << "to quit, type C-c in the terminal" << std::endl;
  srand(time(0));
  Simu s(500, 500);
  std::string arg = "--file";
  if (argc > 1) {
    if (arg.compare(argv[1]) ==0) {
      std::ifstream myfile;
      myfile.open(argv[2]);
      while ( std::getline(myfile,arg) )
      {
        std::cout << arg << '\n';
        std::vector<std::string> vect = split(arg," ");

        if (vect.at(0) == "RECT") {
          s += new Cube(std::stof(vect.at(1)),std::stof(vect.at(2)),std::stof(vect.at(3)),std::stof(vect.at(4)),std::stof(vect.at(5)),std::stof(vect.at(6)));
        }
        if (vect[0] == "BALL") {
          s += new Ball(std::stof(vect.at(1)),std::stof(vect.at(2)),std::stof(vect.at(3)),std::stof(vect.at(4)),std::stof(vect.at(5)));
        }
        }
        myfile.close();
      }

    }



  s += new Cube(randgen::uniform(300) + 100, randgen::uniform(300) + 100,
                randgen::uniform(50) - 25, randgen::uniform(50) - 25,
                randgen::uniform(100), randgen::uniform(100));

  for (size_t i = 0; i < 3; ++i)
    s += new Ball(randgen::uniform(300) + 100, randgen::uniform(300) + 100,
                  randgen::uniform(50) - 25, randgen::uniform(50) - 25,
                  randgen::uniform(30));

  for (size_t i = 0; i < 15000; ++i)
    s.update();

  return 0;
}
