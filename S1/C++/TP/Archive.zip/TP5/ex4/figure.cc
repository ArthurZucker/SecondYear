#include "figure.hh"
Figure::Figure(float x, float y, float vx, float vy,float ax, float ay) : x(x),y(y),vx(vx),vy(vy),ax(ax),ay(ay){

}
