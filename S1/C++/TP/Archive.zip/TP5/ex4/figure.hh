#ifndef __FIGURE_HH
#define __FIGURE_HH
#include "screen.hh"
namespace game {
	const float dt = 0.1;
	const float kx = 0.95;
	const float ky = 0.85;
} /* game */
class Figure {
protected:
	float x,y,vx,vy,ax,ay;
public:
	Figure(float x, float y, float vx, float vy,float ax, float ay);
	virtual void update(Screen &s) = 0;
	virtual void draw(Screen &s) const = 0 ;
	virtual bool is_collided_edges(const Screen &S) const =0 ;
	virtual bool is_collided_floor(const Screen &S) const= 0;
};
#endif
