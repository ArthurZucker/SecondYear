#ifndef __BALL_HH
#define __BALL_HH
#include "screen.hh"
#include "figure.hh"
class Ball : public Figure{
private:
	float radius;
public:
	Ball (float, float, float, float, float);
	void update(Screen &s);
	void draw(Screen &s) const;
	bool is_collided_edges(const Screen &S) const;
	bool is_collided_floor(const Screen &S) const;
	~Ball (){}
};
#endif
