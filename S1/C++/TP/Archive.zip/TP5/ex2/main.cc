#include <iostream>

#include "screen.hh"
#include "ball.hh"
#include "cube.hh"

int main(int argc, char **argv)
{
  std::cerr << "to quit, type C-c in the terminal" << std::endl;
  srand(time(0));
  Screen screen(500, 500);
  Cube c1(100, 100, -10, 20, 20, 30);
  Ball b1(100, 200, 10, 20, 22);
  Ball b2(120, 20, 10, -30, 12);

  for (size_t i = 0; i < 50000; ++i)
  {
    c1.update(screen);
    b1.update(screen);
    b2.update(screen);

    b1.draw(screen);
    b2.draw(screen);
    c1.draw(screen);

    screen.flip();
  }
  return 0;
}
