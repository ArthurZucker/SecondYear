#ifndef __CUBE__HH
#define __CUBE__HH
#include "figure.hh"

class Cube : public Figure
{
private:
	float w, h;

public:
	Cube (float a, float b, float c, float d, float e, float f);
	void update(Screen &s);
	void draw(Screen &s) const;
	bool is_collided_edges(const Screen &S) const;
	bool is_collided_floor(const Screen &S) const;
};

#endif
