#include "ExpBin.hh"
ExpBin::ExpBin( ExpLog &opa, ExpLog &opb) : op1(opa), op2(opb)
{
}
ExpBin::~ExpBin()
{	
}