// Let Catch provide main():
#define CATCH_CONFIG_MAIN

#include "catch.hpp"

TEST_CASE( "1: All test cases reside in other .cpp files (empty)" ) {
}

