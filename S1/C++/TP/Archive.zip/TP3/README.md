# TP4 : Les molecules
TP sur les conteneurs de la STL

* molecules.pdf : le sujet
* molecules.cc : Un programme de test à modifier selon les besoins
* utility.cc/utility.hh : Une bibliothèque contenant une fonction spli
* molecules.txt : exemple de molecules
* reactions.txt : exemple de réactions chimiques

Dès que vous créez un nouveau fichier ajouter le au dépôt
``git add fichier ``

A la fin de la séance votre projet doit étre mis dans le répo avec la commande
``git push``

Vérifier que vous avez bien tout comité
``git status``


## Le lien :
https://classroom.github.com/assignment-invitations/7cb378a4f32469b57e8f3e1f33036724
